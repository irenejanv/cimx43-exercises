#Bean Trial SVG Mapping
<br>

1. I was able to get the SVG code from Illustrator for the first bean day and put it into VS code.<br>
2. When a user hovers over the blue box that says "black bean burgers" I want a tooltip to appear which will hold an Illustrator image of a black bean burger. <br>
3. The path class for the blue rectangle is "st1" <br>
   <path class="st1" d="M103.2,77.3h91c5.5,0,9.9,4.4,9.9,9.9v28.3c0,5.5-4.4,9.9-9.9,9.9h-91c-5.5,0-9.9-4.4-9.9-9.9V87.2
   			C93.4,81.7,97.8,77.3,103.2,77.3z"></path>
4. I am trying to add Hover CSS code to the class .st1 but it isn't working.
5. I tried to add a div around the path to maybe link the hover state to the div around the path, but that destroyed the SVG image.
